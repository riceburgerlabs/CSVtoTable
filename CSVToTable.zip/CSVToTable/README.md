A simple piece of code that takes a CSV file and exports a lua file that can be included in a project.

Blog Post for this project - https://wp.me/p8wqYd-pc

Example Google Sheet - https://docs.google.com/spreadsheets/d/1w0mIvjB1IaWndKN_f3U4RrVjiLrRrHBSYJMWS7y05pA/edit?usp=sharing

Youtube Video - https://youtu.be/N2X4FMTBIr4

-----------------
NOTE - SSK Folder
-----------------
My code realize heavily on Roaming Gamers "Super Starter Kit"
You can find relevant information and downlod the latest version from the websites below

https://roaminggamer.github.io/RGDocs/pages/SSK2/

https://github.com/roaminggamer/SSK2
