application = 
{
    license = {
        google = {
 --           key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqyvF9zZVB9M9qGBWVT6LLpykuHN3/MKpxmx7FXp4OANNINfU2Ab4J0mreKkRSWeQyzOSLLCZRTlVi4vzlvuJJs15zPXxRgwNWOatZ3WE8+PHc3S/64fD2++53U3QBUAU2BB/p7zo+1/a8YScx/ACGwPJzruXdpMPcrNkX3+mGhFEmnnrW7UXfMglRE83NtGxrB1CCrwOyP3OAl/TGMLZGRa0A4hdIQAYqmgxQP/No7Zfc2lGtYZD292Nu2sxCXJgDZyJkqCH3v4EsiNQ8dgaTDK3l21v1aac2HkT+uO2jGra8ZVC1KB4/UhGzIiRhE7GXow+/HvpxlsUGUtWanFRIwIDAQAB"
            key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiOgAlFn07WTbGnBKgtdsCt7qIp1kBLC0Z+9CEJYYjQXojdmV1U2tPjt2WXDf189eaD5Thz55SFNJkh8yAWUDdO+INUhuaSu/9irZWIBtmnbBMovxhE03ersaHhwV4+1EW9/EYCRvogHNR2KYPZxzQT2HpTNAMSX+mUGy78Qw49XgJa1elk1ga6S3LWPDrlnItJ0SS8Smp6NulUQlIw/86eZlkDGHnIDtCVvLuZqEFljOjEkLmDL98ACwKs32Wxg0EAk0GozxBNrEUtRUn2RXVxf8VwqUQhk8xbQ0jm9QlmgtIk+hMmS4Z8Rc2jJBQ/ud8VL1ilzYR0r1xWQ0SsgXMwIDAQAB"
        },
    },
    content = 
    {
        scale = "adaptive",
        fps = 60,

        imageSuffix =
        {
            ["@2x"] = 1.5,
            ["@3x"] = 2.5,
        }
    }
}