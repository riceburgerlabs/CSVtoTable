Shows the outputted Lua file in use
